
#---------------------------------------------------------------------------------------------------------
# Content Based Filtering Method
#---------------------------------------------------------------------------------------------------------
#Getting present working Directory
getwd()
#Modifying working directory

setwd('D:/Fall-19/Data Mining/Project/Movielens_Project/movielens-20m-dataset/')

# Loading data from CSV file
#Movie_ratings=read.csv('rating.csv',header=T)
Movie_ratings=read.csv('ratings_small.csv',header=T)
Movie_data=read.csv('movie.csv',header=T)
Movie_Genres = as.data.frame(Movie_data$genres, stringsAsFactors=FALSE)


# Dealing with Genre
#install.packages("data.table")
library(data.table)
Genre = as.data.frame(tstrsplit(Movie_Genres[,1], '[|]', type.convert=TRUE), stringsAsFactors=FALSE)
head(Genre)
colnames(Genre) = c(1:7)
View(Genre, title = "Genre Matrix")
Total_Genre=print(unlist(Genre))  
Genre_List = unique(Total_Genre)
print(Genre_List)

# Removing junk values 
Genre_List = Genre_List[-19]
Genre_List = Genre_List[-19]
Genre_List = Genre_List[-19]
dim(Genre)
Genre_Matrix_Bin = matrix(0,27278,18)
Genre_Matrix_Bin[1,] = Genre_List
colnames(Genre_Matrix_Bin) = Genre_List
head(Genre_Matrix_Bin[1,])
dim(Genre_Matrix_Bin)

#Framing  Genre matrix
for (i in 1:ncol(Genre)) {
  for (c in 1:10) {
    Gen_Mat_col = which(Genre_Matrix_Bin[1,] == Genre[i,c])
    print(Gen_Mat_col)
    Genre_Matrix_Bin[i+1,Gen_Mat_col] = 1
  }
}

head(Genre_Matrix_Bin)
head(Movie_Genres)

# Convert Genre matrix into dataframe
Genre_Matrix_DF <- as.data.frame(Genre_Matrix_Bin[-1,], stringsAsFactors=FALSE) #remove first row, which was the genre list

# Convert from characters to integers in Genre matrix 
for (c in 1:ncol(Genre_Matrix_DF)) {
  Genre_Matrix_DF[,c] <- as.integer(Genre_Matrix_DF[,c])
} 

View(Genre_Matrix_DF, title = "Genre Matrix - Binary")
dim(Genre_Matrix_DF)
head(Genre_Matrix_DF)

head(Movie_ratings)

# Dealing with rating
Normalize_Ratings = Movie_ratings

# Assinging rating >3 as 1 and <=3 as -1
for (i in 1:nrow(Normalize_Ratings)){
  if (Normalize_Ratings[i,3] > 3){
    Normalize_Ratings[i,3] = 1
  }
  else{
    Normalize_Ratings[i,3] = -1
  }
}

head(Normalize_Ratings)
Binary_Ratings = reshape2::dcast(Normalize_Ratings, movieId~userId, value.var = "rating", na.rm=FALSE)
head(Binary_Ratings)

for (i in 1:ncol(Binary_Ratings)){
  Binary_Ratings[which(is.na(Binary_Ratings[,i]) == TRUE),i] = 0
}

Binary_Ratings = Binary_Ratings[,-1] #remove movieIds col. Rows are movieIds, cols are userIds
#Ratings_Matrix<-as(Binary_Ratings,"realRatingMatrix")

movieIds = length(unique(Movie_data$movieId))
ratingmovieIds = length(unique(Movie_ratings$movieId)) 

# Total Movies in rating db 27278, total movies 9066

#movies2 <- Movie_data[-which((movieIds %in% ratingmovieIds) == FALSE),]
#rownames(movies2)

#Remove rows that are not rated from Genre_Matrix_DF
Genre_Matrix = Genre_Matrix_DF[-which((movieIds %in% ratingmovieIds) == FALSE),] # 1 row has been removed
#rownames(Genre_Matrix) = NULL

head(Genre_Matrix)

#Calculate dot product for User Profiles

User_Prof = matrix(0,18,9066) # 706 ???
for (c in 1:ncol(Binary_Ratings)){
  for (i in 1:ncol(Genre_Matrix)){
    User_Prof[i,c] = sum((Genre_Matrix[,i]) * (Binary_Ratings[,c]))
  }
}

dim(User_Prof)
head(User_Prof)

#Convert to Binary scale
for (i in 1:nrow(User_Prof)){
  if (User_Prof[i] < 0){
    User_Prof[i] = 0
  }
  else {
    User_Prof[i] = 1
  }
}

#Calculate Jaccard distance between user profile and all movies
#install.packages("proxy")
library(proxy)

#install.packages("philentropy")
#library(philentropy)
#getDistMethods()

# Selecting user's profile for recommending : user 1}
head(User_Prof[1,])
View(User_Prof, title = "User Profile")
For_User = User_Prof[1,] 

# Framing similarity matrix for selected user wrt his genre pref
sim_mat = rbind.data.frame(For_User, Genre_Matrix)

#convert data to type integer
sim_mat = data.frame(lapply(sim_mat,function(x){as.integer(x)})) 

gc()
# Distance measure jaccard, cosine not working
sim_results = dist(sim_mat, method = "euclidean")

sim_results <- as.data.frame(as.matrix(sim_results[1:8552])) ## 8552? ??
Rel_Rows <- which(sim_results == min(sim_results))
head(sim_results)
#Recommended movies
View(Movie_data[Rel_Rows,], title = "Content Based Movie Rec - User1")
head(Movie_data[Rel_Rows,])

sim_results
#-----------------------------
eval_scheme_IB = evaluationScheme(ratings_movie1, method="split", train=0.8, given=10,goodRating=5)

eval_model_IB = Recommender(getData(eval_scheme_IB, "train"), method = "IBCF", 
                            param=list(normalize = "center", method="Cosine", k=30))

Prediction_IB = predict(eval_model_IB, getData(eval_scheme_IB, "known"), type="ratings")
