#----------------------------------------------------------------------------------------------------------------------------------------------------
# Classification KNN
#----------------------------------------------------------------------------------------------------------------------------------------------------

#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Fall-19/Data Mining/Project/Movielens_Project/Classification/')

# Loading data from CSV file
Movie_IMDB=read.csv('imdb.csv',header=T)

#---------------------------Data pre processing-------------------------------------------
# Handling dirty values for No.of.Wins column

Movie_IMDB$nrOfWins=as.numeric(as.character(Movie_IMDB$nrOfWins))
#wins_IMDB=ifelse(is.na(wins_IMDB),0,wins_IMDB)
summary(Movie_IMDB$nrOfWins)

# Handling dirty values for No.of.Nominations column
Movie_IMDB$nrOfNominations=as.numeric(as.character(Movie_IMDB$nrOfNominations))
summary(Movie_IMDB$nrOfNominations)

# Handling dirty values for Rating count column
Movie_IMDB$ratingCount=as.numeric(as.character(Movie_IMDB$ratingCount))
summary(Movie_IMDB$ratingCount)

# Handling dirty values for NewsArticles count
Movie_IMDB$nrOfNewsArticles=as.numeric(as.character(Movie_IMDB$nrOfNewsArticles))
summary(Movie_IMDB$nrOfNewsArticles)
 
# Genre split
Movie_IMDB$Action=as.numeric(as.character(Movie_IMDB$Action))
summary(Movie_IMDB$Action)

Movie_IMDB$Adult=as.numeric(as.character(Movie_IMDB$Adult))
summary(Movie_IMDB$Adult)

Movie_IMDB$Adventure=as.numeric(as.character(Movie_IMDB$Adventure))
summary(Movie_IMDB$Adventure)

Movie_IMDB$Animation=as.numeric(as.character(Movie_IMDB$Animation))
summary(Movie_IMDB$Animation)

Movie_IMDB$Biography=as.numeric(as.character(Movie_IMDB$Biography))
summary(Movie_IMDB$Biography)

Movie_IMDB$Comedy=as.numeric(as.character(Movie_IMDB$Comedy))
summary(Movie_IMDB$Comedy)

Movie_IMDB$Crime=as.numeric(as.character(Movie_IMDB$Crime))
summary(Movie_IMDB$Crime)

Movie_IMDB$Documentary=as.numeric(as.character(Movie_IMDB$Documentary))
summary(Movie_IMDB$Documentary)

Movie_IMDB$Drama=as.numeric(as.character(Movie_IMDB$Drama))
summary(Movie_IMDB$Drama)

Movie_IMDB$Family=as.numeric(as.character(Movie_IMDB$Family))
summary(Movie_IMDB$Family)

Movie_IMDB$Fantasy=as.numeric(as.character(Movie_IMDB$Fantasy))
summary(Movie_IMDB$Fantasy)

Movie_IMDB$FilmNoir=as.numeric(as.character(Movie_IMDB$FilmNoir))
summary(Movie_IMDB$FilmNoir)

Movie_IMDB$GameShow=as.numeric(as.character(Movie_IMDB$GameShow))
summary(Movie_IMDB$GameShow)

Movie_IMDB$History=as.numeric(as.character(Movie_IMDB$History))
summary(Movie_IMDB$History)

Movie_IMDB$Horror=as.numeric(as.character(Movie_IMDB$Horror))
summary(Movie_IMDB$Horror)

Movie_IMDB$Music=as.numeric(as.character(Movie_IMDB$Music))
summary(Movie_IMDB$Music)

Movie_IMDB$Musical=as.numeric(as.character(Movie_IMDB$Musical))
summary(Movie_IMDB$Musical)

Movie_IMDB$Mystery=as.numeric(as.character(Movie_IMDB$Mystery))
summary(Movie_IMDB$Mystery)

Movie_IMDB$News=as.numeric(as.character(Movie_IMDB$News))
summary(Movie_IMDB$News)

Movie_IMDB$RealityTV=as.numeric(as.character(Movie_IMDB$RealityTV))
summary(Movie_IMDB$RealityTV)

Movie_IMDB$Romance=as.numeric(as.character(Movie_IMDB$Romance))
summary(Movie_IMDB$Romance)

Movie_IMDB$SciFi=as.numeric(as.character(Movie_IMDB$SciFi))
summary(Movie_IMDB$SciFi)

Movie_IMDB$Short=as.numeric(as.character(Movie_IMDB$Short))
summary(Movie_IMDB$Short)

Movie_IMDB$Sport=as.numeric(as.character(Movie_IMDB$Sport))
summary(Movie_IMDB$Sport)

Movie_IMDB$TalkShow=as.numeric(as.character(Movie_IMDB$TalkShow))
summary(Movie_IMDB$TalkShow)

Movie_IMDB$Thriller=as.numeric(as.character(Movie_IMDB$Thriller))
summary(Movie_IMDB$Thriller)

Movie_IMDB$War=as.numeric(as.character(Movie_IMDB$War))
summary(Movie_IMDB$War)

Movie_IMDB$Western=as.numeric(as.character(Movie_IMDB$Western))
summary(Movie_IMDB$Western)

# Checking dirty values for other features
summary(Movie_IMDB$nrOfUserReviews)
summary(Movie_IMDB$nrOfGenre)

Movie_IMDB$nrOfPhotos=as.numeric(as.character(Movie_IMDB$nrOfPhotos))
summary(Movie_IMDB$nrOfPhotos)

Movie_IMDB$duration=as.numeric(as.character(Movie_IMDB$duration))
summary(Movie_IMDB$duration)

# Handling dirty values for Rating IMDB
Movie_IMDB$imdbRating=as.numeric(as.character(Movie_IMDB$imdbRating))
summary(Movie_IMDB$imdbRating)

#---------------------------Data Transformation-------------------------------------------
Movie_IMDB$imdbRating=cut(Movie_IMDB$imdbRating,breaks = c(0.0,2.5,5.0,8.5,10.0),labels=c("Bad","Fair","Good","Amazing"),right=FALSE)
head(Movie_IMDB$imdbRating)
summary(Movie_IMDB)

#install.packages('caret', dependencies = TRUE)
library(caret)
#---------------------------# Model 1 - Full MODEL-------------------------------------------

subset_1=c("imdbRating","nrOfWins","nrOfNominations","ratingCount","nrOfNewsArticles","nrOfUserReviews","nrOfGenre","nrOfPhotos",	"duration", "Action",	"Adult",	"Adventure",	"Animation",	"Biography",	"Comedy",	"Crime",	"Documentary", 	"Drama"	, "Family", 	"Fantasy", "FilmNoir", "GameShow","History","Horror","Music","Musical","Mystery","News","RealityTV","Romance","SciFi","Short","Sport","TalkShow","Thriller","War","Western")

IMDB_M1_1=Movie_IMDB[subset_1]

IMDB_M1_2=na.omit(IMDB_M1_1)
y1=IMDB_M1_2$imdbRating
head(IMDB_M1_2)

IMDB_M1_2=IMDB_M1_2[-1]

# Normalizing independent attributes
num_vars=sapply(IMDB_M1_2,is.numeric)
IMDB_M1_2[num_vars]=lapply(IMDB_M1_2[num_vars],scale)
head(IMDB_M1_2)
x1=IMDB_M1_2

KNN_M1=train(x1,y1,'knn',trControl = trainControl(method = 'cv',number = 10),tuneGrid = expand.grid(k=51:59))
print(KNN_M1)

#KNN_M1 = train(x1,y1, data = IMDB_Data_2, method = "knn", trControl=trainControl(method = "cv", number = 5), tuneLength = 10)

#---------------------------# Model 2 - 8 Features MODEL-------------------------------------------

subset_2=c("imdbRating","nrOfWins","nrOfNominations","ratingCount","nrOfNewsArticles","nrOfUserReviews","nrOfGenre","nrOfPhotos","duration")

IMDB_M2_1=Movie_IMDB[subset_2]
summary(IMDB_M2_1)

IMDB_M2_2=na.omit(IMDB_M2_1)
summary(IMDB_M2_2)

IMDB_M2_2=IMDB_M2_2[-1]
y2=IMDB_M2_2$imdbRating

# Normalizing independent attributes
num_vars=sapply(IMDB_M2_2,is.numeric)
IMDB_M2_2[num_vars]=lapply(IMDB_M2_2[num_vars],scale)
head(IMDB_M2_2)

x2=IMDB_M2_2

KNN_M2=train(x2,y2,'knn',trControl = trainControl(method = 'cv',number = 10),tuneGrid = expand.grid(k=51:59))
print(KNN_M2)

#---------------------------Feature selection-------------------------------------------
control=rfeControl(functions = rfFuncs,method = "cv",number = 10)
Features_Select=rfe(IMDB_M3_2[,1:8],y3,sizes = c(1:8),rfeControl = control)
print(Features_Select)
predictors(Features_Select)
plot(Features_Select, type = c("g","o"))

#---------------------------# Model 3 -Features selected MODEL-------------------------------------------

subset_3=c("imdbRating","nrOfWins","nrOfNominations","ratingCount","nrOfNewsArticles","duration")

IMDB_M3_1=Movie_IMDB[subset_3]
head(IMDB_M3_1)

#IMDB_Data_2=Movie_IMDB[subset_1]
IMDB_M3_2=na.omit(IMDB_M3_1)
summary(IMDB_M3_2)

y3=IMDB_M3_2$imdbRating
IMDB_M3_2=IMDB_M3_2[-1]
# Normalizing independent attributes
num_vars=sapply(IMDB_M3_2,is.numeric)
IMDB_M3_2[num_vars]=lapply(IMDB_M3_2[num_vars],scale)
head(IMDB_M3_2)
summary(IMDB_M3_2)

# Normalizing independent attributes
num_vars=sapply(IMDB_M3_2,is.numeric)
IMDB_M3_2[num_vars]=lapply(IMDB_M3_2[num_vars],scale)
head(IMDB_M3_2)

x3=IMDB_M3_2
KNN_M3=train(x3,y3,'knn',trControl = trainControl(method = 'cv',number = 10),tuneGrid = expand.grid(k=51:59))
print(KNN_M3)


#---------------------------# Model 4 -Features selected MODEL excluding popularity-------------------------------------------

subset_4=c("imdbRating","nrOfWins","nrOfNominations","duration")

IMDB_M4_1=Movie_IMDB[subset_4]
head(IMDB_M4_1)

#IMDB_Data_2=Movie_IMDB[subset_1]
IMDB_M4_2=na.omit(IMDB_M4_1)
summary(IMDB_M4_2)

y4=IMDB_M4_2$imdbRating
IMDB_M4_2=IMDB_M4_2[-1]
# Normalizing independent attributes
num_vars=sapply(IMDB_M4_2,is.numeric)
IMDB_M4_2[num_vars]=lapply(IMDB_M4_2[num_vars],scale)
head(IMDB_M4_2)
summary(IMDB_M4_2)

# Normalizing independent attributes
num_vars=sapply(IMDB_M4_2,is.numeric)
IMDB_M4_2[num_vars]=lapply(IMDB_M4_2[num_vars],scale)
head(IMDB_M4_2)

x4=IMDB_M4_2
KNN_M4=train(x4,y4,'knn',trControl = trainControl(method = 'cv',number = 10),tuneGrid = expand.grid(k=51:59))
print(KNN_M4)

#---------------------------# Model 5 -major features MODEL excluding popularity-------------------------------------------
subset_5=c("imdbRating","nrOfGenre","nrOfPhotos","duration")

IMDB_M5_1=Movie_IMDB[subset_5]
head(IMDB_M5_1)

#IMDB_Data_2=Movie_IMDB[subset_1]
IMDB_M5_2=na.omit(IMDB_M5_1)
summary(IMDB_M5_2)

y5=IMDB_M5_2$imdbRating
IMDB_M5_2=IMDB_M5_2[-1]
# Normalizing independent attributes
num_vars=sapply(IMDB_M5_2,is.numeric)
IMDB_M5_2[num_vars]=lapply(IMDB_M5_2[num_vars],scale)
head(IMDB_M5_2)
summary(IMDB_M5_2)

# Normalizing independent attributes
num_vars=sapply(IMDB_M5_2,is.numeric)
IMDB_M5_2[num_vars]=lapply(IMDB_M5_2[num_vars],scale)
head(IMDB_M5_2)

x5=IMDB_M5_2
KNN_M5=train(x5,y5,'knn',trControl = trainControl(method = 'cv',number = 10),tuneGrid = expand.grid(k=51:59))
print(KNN_M5)
