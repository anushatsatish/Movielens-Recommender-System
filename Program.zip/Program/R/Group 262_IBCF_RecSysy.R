#----------------------------------------------------------------------------------------------------------------------------------------------------
# Recommender system
#----------------------------------------------------------------------------------------------------------------------------------------------------

#Get working Directory
getwd()

#Set working directory
setwd('D:/Fall-19/Data Mining/Project/Final_Presentation/')

# Loading data from CSV file
Movie_ratings=read.csv('ratings_small.csv',header=T)
Movie_data=read.csv('movie.csv',header=T)
head(Movie_data)

#install.packages("recommenderlab", dependencies = TRUE,)
library(recommenderlab)

movierate = Movie_ratings
movierate = as(Movie_ratings, "realRatingMatrix")

ratings_movie = movierate[rowCounts(movierate) > 50, colCounts(movierate) > 100]
ratings_movie1 = ratings_movie[rowCounts(ratings_movie) > 30,]

set.seed(101)
trainset=sample(x = c(TRUE, FALSE), size = nrow(ratings_movie1), replace = TRUE, 
                prob = c(0.8, 0.2))

MRating_train = ratings_movie1[trainset, ]
MRating_test = ratings_movie1[!trainset, ]

nrow(MRating_train)
nrow(MRating_test)

num_rec = 5  # Lets recommend top 5  movies to each of users


#---------------------------------------------------------------------------------------------------------
# Item Based Collaborative Filtering Method
#---------------------------------------------------------------------------------------------------------
# Find top 5 recommended movies with Item based collab filter
Rec_IB_Model1 = Recommender(data = MRating_train, method = "IBCF", parameter = list(k = 25,  method = "Cosine"))
Rec_IB_Model1

Model1_IB_Predict = predict(object = Rec_IB_Model1, newdata = MRating_test, n = num_rec,type="topNList")
Model1_IB_Predict

class(Model1_IB_Predict)

#------------------------------------------------------------------------------------------------------------------------------
# Creating matrix of user vs their top recommended movies
#------------------------------------------------------------------------------------------------------------------------------
M1_Total_User=length(Model1_IB_Predict@items)
M1_Toprec_allUser = matrix("null",nrow=M1_Total_User,ncol=num_rec) 
dimnames(M1_Toprec_allUser)=list(rownames(M1_Toprec_allUser, do.NULL = FALSE, prefix = "User"),colnames(M1_Toprec_allUser,do.NULL = FALSE,prefix = "Movie"))
for (userId in 1:M1_Total_User){
  For_User = Model1_IB_Predict@items[[userId]]  
  Movie_Id_Foruser <- Model1_IB_Predict@itemLabels[For_User]
  Movies_Reccom_Foruser <- Movie_Id_Foruser
  for (index in 1:num_rec){
    Movies_Reccom_Foruser[index] <- as.character(subset(Movie_data,Movie_data$movieId == Movie_Id_Foruser[index])$title)
    M1_Toprec_allUser[userId,index]=Movies_Reccom_Foruser[index]
  }
#  IBCF_Movies[=(cbind(userId,M1_Toprec_allUser[userId,]))
}

head(M1_Toprec_allUser)
View(M1_Toprec_allUser,title = "Recommended movies using IBCF")
#--------------------------------------------------------------------
## predict ratings for new users
Predict_Rating = predict(Rec_IB_Model1, MRating_test, type="ratings")
Predict_Rating@data
as(Predict_Rating, "matrix")[,1:10]
#----------------------------------------------------------------------------------------------------------------------
#ACCURACY
#----------------------------------------------------------------------------------------------------------------------
#Building Models 
model_IB = Recommender(MRating_train, method = "IBCF",param=list(normalize = "center", method="Cosine", k=30))

#Making predictions 
prediction = predict(model_IB, MRating_test[1:5], type="ratings")
as(prediction, "matrix")[,1:8]

#---------? ???

#Estimating RMSE
set.seed(101)

eval_scheme_IB = evaluationScheme(ratings_movie1, method="split", train=0.8, given=10,goodRating=5)

eval_model_IB = Recommender(getData(eval_scheme_IB, "train"), method = "IBCF", 
                            param=list(normalize = "center", method="Cosine", k=30))

Prediction_IB = predict(eval_model_IB, getData(eval_scheme_IB, "known"), type="ratings")

#RMSE for an entire model
IBCF_Fullaccuracy = calcPredictionAccuracy(Prediction_IB, getData(eval_scheme_IB, "unknown"))
IBCF_AccuracyByUser = calcPredictionAccuracy(Prediction_IB, getData(eval_scheme_IB, "unknown"),byUser = TRUE)
#-------- IBCF ------------
print(IBCF_Fullaccuracy)
print(head(IBCF_AccuracyByUser))
library(knitr) 
# User Rating Prediction accuracy(Sample) - IBCF
#-------- IBCF ------------
kable(print(IBCF_Fullaccuracy),col.names = "IBCF",caption = "Rating Prediction accuracy(Sample) - IBCF")
kable(head(IBCF_AccuracyByUser),caption = "User Rating Prediction accuracy(Sample) - IBCF")
#----------------------------------------------------------------------------------------------------------------------
#Precision and Recall
#----------------------------------------------------------------------------------------------------------------------

#install.packages("precrec")
library(precrec)

Evaluate_result_IBCF = evaluate(eval_scheme_IB,method="IBCF",n=c(1,3,5,10,15,20))
Evaluate_IBCF = getConfusionMatrix(Evaluate_result_IBCF)[[1]]
print(Evaluate_IBCF)
kable(print(Evaluate_IBCF),caption = "User Rating Prediction accuracy(Sample) - IBCF")

#----------------------------------------------------------------------------------------------------------------------
# Model Comparison 
#----------------------------------------------------------------------------------------------------------------------
#----------------------------- RMSE, MAE, MSE ---------------------
#-----------------------------IBCF---------------------
print(head(IBCF_AccuracyByUser))
print(IBCF_Fullaccuracy)
print(head(UBCF_AccuracyByUser))
print(UBCF_Fullaccuracy)
print(MF_Fullaccuracy)
print(head(MF_accuracyByuser))

#install.packages("devtools", dependencies = TRUE)
library(devtools)
RMSE_DF=c(IBCF_Fullaccuracy[1],UBCF_Fullaccuracy[1],MF_Fullaccuracy[1])
barplot(h[1],xName="UBCF")
plot(RMSE_DF,col=c("red","blue","green"),pch=15,main="RMSE Comparison",xlab="Rec Sys Model",ylab="RMSE")
legend(1, 95, legend=c("Line 1", "Line 2", "Line 3"),col=c("red", "blue","green"), lty=1:2, cex=0.8)


bartable = table(IBCF_Fullaccuracy[1],UBCF_Fullaccuracy[1],MF_Fullaccuracy[1])  ## get the cross tab
barplot(as.matrix(bartable), beside = TRUE, main = "FacVar1=level1")
#----------------------------- PRECISION & RECALL ------------------------------------------
print(Evaluate_IBCF)
print(Evaluate_UBCF)
print(Evaluate_MF)
#----------------------------- ROC ---------------------------------------------------------------

# Evaluating different models, we can define a list with them We add random and
# popular to the model methods of evaluation in this comparison

models_to_evaluate = list(IBCF_cos = list(name = "IBCF", param = list(method = "cosine")), 
                          UBCF_cos = list(name = "UBCF", param = list(method = "cosine")))
                          
# In order to evaluate the models properly, we need to test them, varying the
# number of flavors , as follows
n_recommendations = c(1, 3, 5, 7, 10, 12, 15)

list_results = evaluate(x = eval_scheme_IB, method = models_to_evaluate, n = n_recommendations)

plot(list_results, annotate = 1, legend = "topleft")
title("ROC curve")

# ---------------------------- Table view --------------------------------------------------------

listerror = evaluate(x = eval_scheme_IB, method = models_to_evaluate, type = "ratings")
modelcomp = as.data.frame(sapply(avg(listerror), rbind))
modelcompnew = as.data.frame(t(as.matrix(modelcomp)))
colnames(modelcompnew) <- c("Model","RMSE", "MSE", "MAE")

#install.packages('pander')
library(pander)
pander(modelcompnew, caption = "Model Comparison Based On Varying Recommendation")

install.packages("knitr")
library(knitr)
kable(modelcompnew)
#---------------------
# Writing files in excel
#install.packages("XLConnect", dependencies = TRUE)
library(XLConnect)
writeWorksheetToFile("Recsys_Accuracy.xlsx",data = IBCF_AccuracyByUser,sheet = "IBCF_Accuracy-User", header = TRUE,clearSheets = TRUE)
writeWorksheetToFile("Recsys_Accuracy.xlsx",data = UBCF_AccuracyByUser,sheet = "UBCF_Accuracy-User", header = TRUE,clearSheets = TRUE)
#writeWorksheetToFile("Recsys_Output.xlsx",data = MF_AccuracyByUser,sheet = "MF_Accuracy-User", header = TRUE,clearSheets = TRUE)
