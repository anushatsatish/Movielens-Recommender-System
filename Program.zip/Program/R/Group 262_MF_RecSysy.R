#---------------------------------------------------------------------------------------------------------
#  MATRIX FACTORIZATION
#---------------------------------------------------------------------------------------------------------
#Get working Directory
getwd()

#Set working directory
setwd('D:/Fall-19/Data Mining/Project/Movielens_Project/movielens-20m-dataset/')

# Loading data from CSV file
Movie_ratings=read.csv('ratings_small.csv',header=T)
Movie_data=read.csv('movie.csv',header=T)

head(Movie_data)
#Matrix_Rating = Movie_ratings %>% dcast(formula = movieId ~ userId) %>% as.matrix()
head(Movie_ratings)
#install.packages("recosystem",dependencies = TRUE)
library(recosystem)

#------------------------------------------------------------------------------------------------------------------------------
# Matrix Factorization
#------------------------------------------------------------------------------------------------------------------------------
MF_recom=Reco()
#Model 1
MF_Trainset = data_memory(Movie_ratings$userId, Movie_ratings$movieId, rating = Movie_ratings$rating)
opts = MF_recom$tune(MF_Trainset, opts = list(dim = c(10, 20, 30), lrate = c(0.1, 0.2),costp_l1 = 0, costq_l1 = 0,nthread = 1, niter = 10))
MF_recom$train(MF_Trainset, opts = opts)

#Model 2
MF_Trainset = data_memory(Movie_ratings$userId, Movie_ratings$movieId, rating = Movie_ratings$rating)
opts = MF_recom$tune(MF_Trainset, opts = list(dim = c(10, 20, 30), lrate = c(0.7, 0.8),costp_l1 = 0, costq_l1 = 0,nthread = 1, niter = 10))
MF_recom$train(MF_Trainset, opts = opts)

#Model 3
MF_Trainset = data_memory(Movie_ratings$userId, Movie_ratings$movieId, rating = Movie_ratings$rating)
opts = MF_recom$tune(MF_Trainset, opts = list(dim = c(10, 20, 30), lrate = c(0.4, 0.5),costp_l1 = 0, costq_l1 = 0,nthread = 1, niter = 10))
MF_recom$train(MF_Trainset, opts = opts)

#Model 4
MF_Trainset = data_memory(Movie_ratings$userId, Movie_ratings$movieId, rating = Movie_ratings$rating)
opts = MF_recom$tune(MF_Trainset, opts = list(dim = c(30, 40, 50), lrate = c(0.4, 0.5),costp_l1 = 0, costq_l1 = 0,nthread = 1, niter = 10))
MF_recom$train(MF_Trainset, opts = opts)

#Model 5
MF_Trainset = data_memory(Movie_ratings$userId, Movie_ratings$movieId, rating = Movie_ratings$rating)
opts = MF_recom$tune(MF_Trainset, opts = list(dim = c(20, 30, 40), lrate = c(0.5, 0.6),costp_l1 = 0, costq_l1 = 0,nthread = 1, niter = 10))
MF_recom$train(MF_Trainset, opts = opts)

#Model 6
MF_Trainset = data_memory(Movie_ratings$userId, Movie_ratings$movieId, rating = Movie_ratings$rating)
opts = MF_recom$tune(MF_Trainset, opts = list(dim = c(10, 20, 30), lrate = c(0.5, 0.6),costp_l1 = 0, costq_l1 = 0,nthread = 1, niter = 10))
MF_recom$train(MF_Trainset, opts = opts)

#------------------------------------------------------------------------------------------------------------------------------
# Creating matrix of user vs their top recommended movies
#------------------------------------------------------------------------------------------------------------------------------
#install.packages("magrittr") 
library(magrittr) 
library(data.table)
num_rec=5
#M3_Total_User=length(Model3_MF_Predict@items)
M3_Total_User=62
M3_Toprec_allUser = matrix("null",nrow=M3_Total_User,ncol=num_rec) 
dimnames(M3_Toprec_allUser)=list(rownames(M3_Toprec_allUser, do.NULL = FALSE, prefix = "User"),colnames(M3_Toprec_allUser,do.NULL = FALSE,prefix = "Movie"))
for (user in 1:M3_Total_User){
  MF_Testset  =  data_memory(rep(c(user),nrow(Movie_data)), Movie_data$movieId, rating = NULL)
  temp=(data.frame(userId = user,movieId = Movie_data$title,rating = MF_recom$predict(MF_Testset, out_memory())) %>%setorder(-rating) %>%head(num_rec))
#  print(temp)
  for (index in 1:num_rec){
    M3_Toprec_allUser[user,index]=as.character(temp[index,2])
  }
}
head(M3_Toprec_allUser[25,])
View(M3_Toprec_allUser,title = "Recommended movies using MF")
#--------------------------------------------------------------------
#install.packages("recommenderlab", dependencies = TRUE,)
library(recommenderlab)
rating <- as(Movie_ratings,"realRatingMatrix")
eval_scheme_MF = evaluationScheme(rating, method="split", train=0.8,k=1, given=10,goodRating=5)
Rec_MF_Model3 <- Recommender(getData(eval_scheme_MF, "train"), "SVD")

#----------------------------------------------------------------------------------------------------------------------
#ACCURACY
#----------------------------------------------------------------------------------------------------------------------

eval_model_MF <- predict(Rec_MF_Model3, getData(eval_scheme_MF, "known"), type = "ratings")
head(eval_model_MF@data)
getRatingMatrix(eval_model_MF)[1:6,1:6]

MF_Fullaccuracy = calcPredictionAccuracy(eval_model_MF, getData(eval_scheme_MF, "unknown"))
MF_accuracyByuser = calcPredictionAccuracy(eval_model_MF, getData(eval_scheme_MF, "unknown"),byUser = TRUE)
#------------------------------------------------------------------------
print(MF_Fullaccuracy)
print(head(MF_accuracyByuser))
#----------------------------------------------------------------------------------------------------------------------
#Precision and Recall
#----------------------------------------------------------------------------------------------------------------------

Evaluate_result_MF = evaluate(eval_scheme_MF,method="SVD",n=c(1,3,5,10,15,20))
Evaluate_MF = getConfusionMatrix(Evaluate_result_MF)[[1]]
print(Evaluate_MF)

library(knitr)
#-------- MF ------------
kable(print(MF_Fullaccuracy),col.names = "MF",caption = "Rating Prediction accuracy(Sample) - MF")
kable(head(MF_accuracyByuser),caption = "User Rating Prediction accuracy(Sample) - MF")
kable(print(Evaluate_MF),caption = "User Rating Prediction accuracy(Sample) - MF")

