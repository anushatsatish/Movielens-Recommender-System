#----------------------------------------------------------------------------------------------------------------------------------------------------
# Recommender system
#----------------------------------------------------------------------------------------------------------------------------------------------------

#Get working Directory
getwd()

#Set working directory
setwd('D:/Fall-19/Data Mining/Project/Final_Presentation/')

# Loading data from CSV file
Movie_ratings=read.csv('ratings_small.csv',header=T)
Movie_data=read.csv('movie.csv',header=T)
head(Movie_data)


#install.packages("recommenderlab", dependencies = TRUE,)
library(recommenderlab)

movierate = Movie_ratings
movierate = as(Movie_ratings, "realRatingMatrix")

ratings_movie = movierate[rowCounts(movierate) > 50, colCounts(movierate) > 100]
ratings_movie1 = ratings_movie[rowCounts(ratings_movie) > 30,]

set.seed(101)
trainset=sample(x = c(TRUE, FALSE), size = nrow(ratings_movie1), replace = TRUE, 
                prob = c(0.8, 0.2))

MRating_train = ratings_movie1[trainset, ]
MRating_test = ratings_movie1[!trainset, ]

nrow(MRating_train)
nrow(MRating_test)

num_rec = 5  # Lets recommend top 5  movies to each of users

#---------------------------------------------------------------------------------------------------------
# User Based Collaborative Filtering Method
#---------------------------------------------------------------------------------------------------------
# Find top 5 recommended movies with Item based collab filter
#200 users

Rec_Ub_Model1 = Recommender(data = MRating_train, method = "UBCF", parameter = list(k = 25, method = "Cosine"))
Rec_Ub_Model1

#Recommender of type 'UBCF' for 'realRatingMatrix' learned using 214 users.                     
Model1_Ub_Predict = predict(object = Rec_Ub_Model1, newdata = MRating_test, n = num_rec,type="topNList")
Model1_Ub_Predict

#----------------------------------------------------------------------------------------
# Creating matrix of user vs their top recommended movies
#----------------------------------------------------------------------------------------
M2_Total_User=length(Model1_Ub_Predict@items)
M2_Toprec_allUser = matrix("null",nrow=M2_Total_User,ncol=num_rec) 
dimnames(M2_Toprec_allUser)=list(rownames(M2_Toprec_allUser, do.NULL = FALSE, prefix = "User"),colnames(M2_Toprec_allUser,do.NULL = FALSE,prefix = "Movie"))
for (userId in 1:M2_Total_User){
  For_User = Model1_Ub_Predict@items[[userId]]  
  Movie_Id_Foruser <- Model1_Ub_Predict@itemLabels[For_User]
  Movies_Reccom_Foruser <- Movie_Id_Foruser
  for (index in 1:num_rec){
    Movies_Reccom_Foruser[index] <- as.character(subset(Movie_data,Movie_data$movieId == Movie_Id_Foruser[index])$title)
    M2_Toprec_allUser[userId,index]=Movies_Reccom_Foruser[index]
  }
}
head(M2_Toprec_allUser)
View(M2_Toprec_allUser,title = "Recommended movies using UBCF")


#----------------------------------------------------------------------------------------------------------------------
#ACCURACY
#----------------------------------------------------------------------------------------------------------------------

#Building Models 
model = Recommender(MRating_train, method = "UBCF", param=list(normalize = "center", method="Cosine"))

#Making predictions 
#Define a matrix with the recommendations for each user. I visualize the recommendations for the first four users:
prediction = predict(model, MRating_test[1:5], type="ratings")
as(prediction, "matrix")[,1:8]

#Estimating RMSE
set.seed(1)
eval_scheme_UB = evaluationScheme(ratings_movie1, method="split",train=0.8, given=10,goodRating=5)
eval_model_UB = Recommender(getData(eval_scheme_UB, "train"), method = "UBCF",param=list(normalize = "center", method="Cosine"))
Prediction_UB = predict(eval_model_UB, getData(eval_scheme_UB, "known"), type="ratings")

#RMSE for an entire model

UBCF_Fullaccuracy = calcPredictionAccuracy(Prediction_UB, getData(eval_scheme_UB, "unknown"),byUser = FALSE)
UBCF_AccuracyByUser = calcPredictionAccuracy(Prediction_UB, getData(eval_scheme_UB, "unknown"),byUser = TRUE)

#--------UBCF
print(head(UBCF_AccuracyByUser))
print(UBCF_Fullaccuracy)
#-------- UBCF ------------

kable(print(UBCF_Fullaccuracy),col.names = "UBCF",caption = "Rating Prediction accuracy(Sample) - UBCF")
kable(head(UBCF_AccuracyByUser),caption = "User Rating Prediction accuracy(Sample) - UBCF")

#----------------------------------------------------------------------------------------------------------------------
#Precision and Recall
#----------------------------------------------------------------------------------------------------------------------

install.packages("precrec")
library(precrec)

Evaluate_result_UBCF = evaluate(eval_scheme_UB,method="UBCF",n=c(1,3,5,10,15,20))
Evaluate_UBCF = getConfusionMatrix(Evaluate_result_UBCF)[[1]]
print(Evaluate_UBCF)

kable(print(Evaluate_UBCF),caption = "User Rating Prediction accuracy(Sample) - UBCF")


